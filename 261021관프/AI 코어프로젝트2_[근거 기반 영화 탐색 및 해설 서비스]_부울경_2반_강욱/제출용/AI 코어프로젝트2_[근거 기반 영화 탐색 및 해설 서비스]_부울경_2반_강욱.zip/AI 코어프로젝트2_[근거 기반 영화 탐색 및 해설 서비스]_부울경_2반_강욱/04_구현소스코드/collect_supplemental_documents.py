"""보완 문서 수집. 공개 HTML만 요청하며 API 키/개인 연락처를 전송하지 않는다."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import quote, unquote
import json, re, time, hashlib
import requests
from html.parser import HTMLParser

class ArticleParser(HTMLParser):
 def __init__(self):
  super().__init__();self.stack=[];self.body=None;self.h1=False;self.heading=[];self.lines=[];self.canonical=None
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='link' and a.get('rel')=='canonical':self.canonical=a.get('href')
  if tag in {'meta','link','br','img','input','hr','wbr','source','area','embed','param','track','col'}:
   if tag=='br' and self.body is not None:self.lines.append('\n')
   return
  classes=set(a.get('class','').split())
  ignored=tag in {'script','style','sup'} or bool(classes & {'navbox','reflist','mw-editsection','toc','metadata','ambox','noprint','sistersitebox','authority-control'})
  self.stack.append((tag,ignored or bool(self.stack and self.stack[-1][1])))
  if self.body is None and 'mw-parser-output' in classes:self.body=len(self.stack)
  if tag=='h1':self.h1=True
  if self.body is not None and tag in {'p','div','tr','li','h2','h3','section'}:self.lines.append('\n')
 def handle_endtag(self,tag):
  if tag=='h1':self.h1=False
  if self.body is not None and tag in {'p','div','tr','li','td','th','h2','h3','section'}:self.lines.append('\n')
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==tag:
    if self.body is not None and i+1<=self.body:self.body=None
    del self.stack[i:];break
 def handle_data(self,data):
  if self.h1:self.heading.append(data)
  if self.body is not None and not (self.stack and self.stack[-1][1]):self.lines.append(data)


ROOT=Path(__file__).resolve().parent

def main():
 import argparse
 from movielab.config import load_settings
 from movielab.preparation.movies import read_movies,is_item_document
 parser=argparse.ArgumentParser(description="보완 영화 13편의 공개 위키 문서 수집/무결성 확인")
 parser.add_argument('--refresh',action='store_true',help='저장된 문서도 다시 다운로드')
 args=parser.parse_args()
 settings=load_settings()
 manifest=json.loads((ROOT/'data/supplemental_movies.json').read_text(encoding='utf-8'))
 movies={str(m['movie_id']):m for m in read_movies(settings.movies_path)}
 session=requests.Session()
 session.headers['User-Agent']='MovieLab-EducationalResearch/1.0'
 for entry in manifest:
  movie=movies[entry['movie_id']];dest=settings.wiki_bundle_path/entry['filename']
  if dest.exists() and not args.refresh:
   document=json.loads(dest.read_text(encoding='utf-8'))
   assert is_item_document(document['title'],movie)
   assert hashlib.sha256(document['text'].encode()).hexdigest()==document['text_sha256']
   print(entry['movie_id'],'기존 원문/해시 확인');continue
  time.sleep(settings.request_interval)
  for attempt in range(settings.request_retries):
   response=session.get(entry['url'],timeout=settings.request_timeout)
   if response.status_code==429 or response.status_code>=500:
    time.sleep(max(1,2**attempt));continue
   response.raise_for_status();break
  else:raise RuntimeError('원문 호출 제한: 잠시 후 재시도하세요.')
  article=ArticleParser();article.feed(response.text)
  title=''.join(article.heading).strip()
  text='\n'.join(line.strip() for line in ''.join(article.lines).splitlines() if line.strip())
  assert is_item_document(title,movie),'다른 작품으로 연결됨'
  assert str(movie['year']) in text and len(text)>=200,'개봉연도/본문 확인 실패'
  pid=re.search(r'"wgArticleId"\s*:\s*(\d+)',response.text)
  revision=re.search(r'"wgRevisionId"\s*:\s*(\d+)',response.text)
  assert pid and pid.group(1)==entry['page_id'],'문서 ID 변경: 작품을 다시 확인하세요.'
  url=article.canonical or response.url
  doc={'movie_id':entry['movie_id'],'page_id':pid.group(1),'title':title,'url':url,'text':text,
   'source':'한국어 위키백과','search_query':movie['title']+' '+str(movie['year'])+' 영화',
   'collected_at':datetime.now(timezone.utc).isoformat(),'source_kind':'wiki',
   'collection_method':'public_article_html','revision_id':revision.group(1) if revision else None,
   'license':'CC BY-SA 4.0','license_url':'https://creativecommons.org/licenses/by-sa/4.0/',
   'attribution_url':url,'history_url':url+'?action=history',
   'transformation':'본문 텍스트 추출; 탐색·각주 목록 제거; 원문 사실 추가/생성 없음',
   'text_sha256':hashlib.sha256(text.encode()).hexdigest()}
  dest.parent.mkdir(parents=True,exist_ok=True)
  dest.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')
  print(entry['movie_id'],'원문 수집 완료')

if __name__=='__main__':main()
