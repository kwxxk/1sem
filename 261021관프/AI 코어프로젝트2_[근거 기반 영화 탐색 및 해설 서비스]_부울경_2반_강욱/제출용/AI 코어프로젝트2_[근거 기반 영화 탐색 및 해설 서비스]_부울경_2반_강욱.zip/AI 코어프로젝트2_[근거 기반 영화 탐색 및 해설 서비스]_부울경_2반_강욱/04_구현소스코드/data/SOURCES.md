# 데이터·문서 출처와 이용 조건

| 자료 | 원문·제공처 | 이용 조건 기록 | 처리 |
|---|---|---|---|
| 영화 메타데이터 964편 | 교육용 제공 TMDB 기반 movies.json, 각 tmdb_url | 제공처 및 https://www.themoviedb.org/terms-of-use 의 허용 범위를 확인. 별도 자유 재배포 허가를 받은 것으로 간주하지 않음. | 영화당 1텍스트. 제출용 사본은 data_assets/에 제공 데이터를 보존하며 원본 작업 프로젝트는 외부 배포 폴더를 참조. |
| 한국어 위키백과 | https://ko.wikipedia.org/ 및 배포 문서별 url | 제공 안내의 CC BY-SA 4.0. https://creativecommons.org/licenses/by-sa/4.0/ | 제목·원문·검색어·수집일 보존. 영화별 청킹·색인. |
| A Field Guide to Black Holes | NASA Goddard, https://science.nasa.gov/resource/a-field-guide-to-black-holes-booklet/ | https://www.nasa.gov/nasa-brand-center/images-and-media/ 및 PDF 안의 제3자 크레딧을 보존. NASA가 제품을 승인했다는 표현을 쓰지 않음. | 원본은 .local/source_pdfs에 저장해 Git 제외. 이미지 재배포 없이 교육용 본문 검색. |

PDF 원문: https://science.nasa.gov/wp-content/uploads/2023/09/black_hole_field_guide_booklet.pdf

2026-10-21 수집한 원본 SHA256:
`e2ca1e01b1ec8426e8e9dd99d1a56db1edb7e526aa148230d3911f761c0988f4`

인터스텔라(157336)의 블랙홀 배경 자료로 연결했다. 이 문서가 영화 제작상의 모든 주장을 확인해 주는 것은 아니다.
영문 PDF의 2~4쪽을 각각 추출한다. 1쪽은 표지·가상 서평·크레딧이어서 검색 본문에서 제외한다.
각 쪽 안에서는 기본 1000/200자 청킹을 사용한다. 위키와 다른 점은 쪽 경계를 넘어 청킹하지 않는 것으로,
파일·쪽 번호를 정확하게 제시하기 위한 선택이다. 원문 링크 #page=N과 source_kind=pdf를 청크마다 저장한다.

추가 PDF는 pdf_manifest.json에 ID·프로젝트 내부 경로·제목·HTTPS 원문·출처·이용 조건·연결 영화 ID를 등록한다.
실제 원문이 없으면 성공으로 꾸미지 않고 fetch-pdfs 안내를 표시한다. 출처·이용 조건이 누락된 등록은 거부한다.


## 2026-10-23 보완 자체 문서 13편

공개 한국어 위키백과 HTML의 본문 텍스트를 추출했다. 보완 문서는 CC BY-SA 4.0으로 제공하며 원문 URL의 역사 보기에서 기여자 이력을 확인할 수 있다. 각 JSON에 revision_id·수집일·저자 이력 링크·변경 내용·라이선스·SHA256을 기록했다. 별칭 보완 외에 원문 사실을 추가 생성하지 않았다.

| 영화 | 위키 원문 | 영화 연도 |
|---|---|---:|
| 혹성탈출: 반격의 서막 | [혹성탈출: 반격의 서막](https://ko.wikipedia.org/wiki/%ED%98%B9%EC%84%B1%ED%83%88%EC%B6%9C:_%EB%B0%98%EA%B2%A9%EC%9D%98_%EC%84%9C%EB%A7%89) | 2014 |
| 19곰 테드 2 | [19곰 테드 2](https://ko.wikipedia.org/wiki/19%EA%B3%B0_%ED%85%8C%EB%93%9C_2) | 2015 |
| 포커스 | [포커스 (2015년 영화)](https://ko.wikipedia.org/wiki/%ED%8F%AC%EC%BB%A4%EC%8A%A4_(2015%EB%85%84_%EC%98%81%ED%99%94)) | 2015 |
| 맨 인 더 다크 | [맨 인 더 다크](https://ko.wikipedia.org/wiki/%EB%A7%A8_%EC%9D%B8_%EB%8D%94_%EB%8B%A4%ED%81%AC) | 2016 |
| 유령 신부 | [유령 신부](https://ko.wikipedia.org/wiki/%EC%9C%A0%EB%A0%B9_%EC%8B%A0%EB%B6%80) | 2005 |
| 모탈 컴뱃 | [모탈 컴뱃 (2021년 영화)](https://ko.wikipedia.org/wiki/%EB%AA%A8%ED%83%88_%EC%BB%B4%EB%B1%83_(2021%EB%85%84_%EC%98%81%ED%99%94)) | 2021 |
| 마약왕 | [마약왕 (영화)](https://ko.wikipedia.org/wiki/%EB%A7%88%EC%95%BD%EC%99%95_(%EC%98%81%ED%99%94)) | 2018 |
| 혹성탈출: 진화의 시작 | [혹성탈출: 진화의 시작](https://ko.wikipedia.org/wiki/%ED%98%B9%EC%84%B1%ED%83%88%EC%B6%9C:_%EC%A7%84%ED%99%94%EC%9D%98_%EC%8B%9C%EC%9E%91) | 2011 |
| 싱크홀 | [싱크홀 (영화)](https://ko.wikipedia.org/wiki/%EC%8B%B1%ED%81%AC%ED%99%80_(%EC%98%81%ED%99%94)) | 2021 |
| 블랙핑크: 세상을 밝혀라 | [블랙핑크: 세상을 밝혀라](https://ko.wikipedia.org/wiki/%EB%B8%94%EB%9E%99%ED%95%91%ED%81%AC:_%EC%84%B8%EC%83%81%EC%9D%84_%EB%B0%9D%ED%98%80%EB%9D%BC) | 2020 |
| 승부 | [승부 (2025년 영화)](https://ko.wikipedia.org/wiki/%EC%8A%B9%EB%B6%80_(2025%EB%85%84_%EC%98%81%ED%99%94)) | 2025 |
| 미스터 & 미세스 스미스 | [미스터 & 미세스 스미스](https://ko.wikipedia.org/wiki/%EB%AF%B8%EC%8A%A4%ED%84%B0_%26_%EB%AF%B8%EC%84%B8%EC%8A%A4_%EC%8A%A4%EB%AF%B8%EC%8A%A4) | 2005 |
| 인디아나 존스: 마궁의 사원 | [인디아나 존스 (영화)](https://ko.wikipedia.org/wiki/%EC%9D%B8%EB%94%94%EC%95%84%EB%82%98_%EC%A1%B4%EC%8A%A4_(%EC%98%81%ED%99%94)) | 1984 |

`data/supplemental_movies.json`은 정확한 영화 page_id와 파일명 목록이다. `python collect_supplemental_documents.py`는 포함 파일의 해시를 검증하고 `--refresh`는 재수집한다. 공개 HTML 요청에는 개인 연락처나 프로젝트 저장소 URL을 넣지 않는다. 포함 문서 모드로 동작하므로 실시간 위키 API 설정이 없어도 보완 13편을 사용할 수 있다.
