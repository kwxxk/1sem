"""Windows Chroma 종료/재초기화 충돌을 피하기 위해 검사별 프로세스로 실행한다.
먼저 python manage.py fetch-pdfs로 PDF 원문을 준비한다.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,sys,time,unittest

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'tests'),str(ROOT)]

def flatten(suite):
 for test in suite:
  if isinstance(test,unittest.TestSuite):yield from flatten(test)
  else:yield test.id()

def run(name):
 started=time.perf_counter()
 try:
  result=subprocess.run([sys.executable,'-m','unittest',name,'-v'],cwd=ROOT/'tests',capture_output=True,timeout=90)
  return {'test':name,'pass':result.returncode==0,'seconds':round(time.perf_counter()-started,3),
   'output':(result.stdout+result.stderr).decode('utf-8',errors='replace')}
 except subprocess.TimeoutExpired:return {'test':name,'pass':False,'output':'90초 제한 시간 초과'}

def main():
 names=list(flatten(unittest.defaultTestLoader.discover(str(ROOT/'tests'))))
 rows=[];path=ROOT/'.local/test-results.json';path.parent.mkdir(exist_ok=True)
 with ThreadPoolExecutor(max_workers=2) as pool:
  for row in pool.map(run,names):
   rows.append(row)
   print(('PASS' if row['pass'] else 'FAIL')+' '+row['test'],flush=True)
   path.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
 print(f"{sum(r['pass'] for r in rows)}/{len(rows)} 통과")
 return 0 if rows and all(r['pass'] for r in rows) else 1

if __name__=='__main__':raise SystemExit(main())
