"""제출 데이터의 자체 문서 누락과 동명 작품 오인 회귀 검사."""
from pathlib import Path
import hashlib,json,sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from movielab.config import load_settings
from movielab.preparation.movies import read_movies,is_item_document
from movielab.preparation.documents import Bundle

class SupplementalDocumentsTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.settings=load_settings()
  cls.movies=read_movies(cls.settings.movies_path)
  cls.by_id={str(m['movie_id']):m for m in cls.movies}
 def test_all_provided_movies_have_own_document(self):
  bundle=Bundle(self.settings)
  self.assertEqual(len(self.movies),964)
  self.assertEqual([m['title'] for m in self.movies if bundle.own_document(m) is None],[])
 def test_supplemental_documents_are_attributed_and_unchanged(self):
  manifest=json.loads((Path(__file__).resolve().parents[1]/'data/supplemental_movies.json').read_text(encoding='utf-8'))
  self.assertEqual(len(manifest),13)
  for entry in manifest:
   with self.subTest(movie_id=entry['movie_id']):
    document=json.loads((self.settings.wiki_bundle_path/entry['filename']).read_text(encoding='utf-8'))
    self.assertTrue(is_item_document(document['title'],self.by_id[entry['movie_id']]))
    self.assertIn(str(entry['year']),document['text'])
    for field in ['url','page_id','collected_at','license','license_url','attribution_url','history_url','revision_id']:
     self.assertTrue(document[field],field)
    self.assertEqual(hashlib.sha256(document['text'].encode()).hexdigest(),document['text_sha256'])
 def test_correct_film_alias_and_remake_year(self):
  self.assertTrue(is_item_document('인디아나 존스 (영화)',self.by_id['87']))
  self.assertFalse(is_item_document('인디아나 존스 (드라마)',self.by_id['87']))
  self.assertTrue(is_item_document('모탈 컴뱃 (2021년 영화)',self.by_id['460465']))
  self.assertFalse(is_item_document('모탈 컴뱃 (1995년 영화)',self.by_id['460465']))

if __name__=='__main__':unittest.main()
